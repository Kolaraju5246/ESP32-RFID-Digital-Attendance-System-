 #include <SPI.h>
#include <MFRC522.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>

// RC522 pins
#define RFID_SS_PIN  5
#define RFID_RST_PIN 4

// Buzzer pin
#define BUZZER_PIN 26

MFRC522 rfid(RFID_SS_PIN, RFID_RST_PIN);
LiquidCrystal_I2C lcd(0x27, 16, 2);

// Registered students: UID, name
struct Student {
  const char* uid;
  const char* name;
  bool present;
};

Student students[] = {
  {"01020304", "Rajuu"},
  {"11223344", "Kishore"},
  {"55667788", "Avinash"},
  {"AABBCCDD", "Harish"}
};

const int STUDENT_COUNT =
  sizeof(students) / sizeof(students[0]);

String getCardUID() {
  String uid = "";

  for (byte i = 0; i < rfid.uid.size; i++) {
    if (rfid.uid.uidByte[i] < 0x10) {
      uid += "0";
    }

    uid += String(rfid.uid.uidByte[i], HEX);
  }

  uid.toUpperCase();
  return uid;
}

int findStudent(String uid) {
  for (int i = 0; i < STUDENT_COUNT; i++) {
    if (uid.equals(students[i].uid)) {
      return i;
    }
  }

  return -1;
}

void beep(int frequency, int duration) {
  tone(BUZZER_PIN, frequency, duration);
  delay(duration + 30);
  noTone(BUZZER_PIN);
}

void showMessage(const char* line1, const char* line2) {
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print(line1);
  lcd.setCursor(0, 1);
  lcd.print(line2);
}

void setup() {
  Serial.begin(115200);

  pinMode(BUZZER_PIN, OUTPUT);
  noTone(BUZZER_PIN);

  Wire.begin(21, 22);
  lcd.init();
  lcd.backlight();

  SPI.begin(18, 19, 23, RFID_SS_PIN);
  rfid.PCD_Init();

  showMessage("Digital Attend.", "Scan your card");

  Serial.println();
  Serial.println("ESP32 Digital Attendance System");
  Serial.println("Registered students:");

  for (int i = 0; i < STUDENT_COUNT; i++) {
    Serial.print(students[i].name);
    Serial.print(" - UID: ");
    Serial.println(students[i].uid);
  }

  Serial.println("System ready. Scan an RFID card.");
}

void loop() {
  if (!rfid.PICC_IsNewCardPresent()) {
    delay(50);
    return;
  }

  if (!rfid.PICC_ReadCardSerial()) {
    delay(50);
    return;
  }

  String uid = getCardUID();

  Serial.println();
  Serial.print("Scanned UID: ");
  Serial.println(uid);

  int studentIndex = findStudent(uid);

  if (studentIndex >= 0) {
    Student &student = students[studentIndex];

    if (!student.present) {
      student.present = true;

      Serial.print("Attendance marked: ");
      Serial.println(student.name);

      showMessage("Welcome:", student.name);
      beep(1800, 150);
    } else {
      Serial.print("Already present: ");
      Serial.println(student.name);

      showMessage("Already Marked", student.name);
      beep(900, 250);
    }
  } else {
    Serial.println("Unknown card - attendance rejected");

    showMessage("Unknown Card", "Access Denied");
    beep(400, 500);
  }

  // Stop current card communication
  rfid.PICC_HaltA();
  rfid.PCD_StopCrypto1();

  delay(1200);

  showMessage("Digital Attend.", "Scan your card");
}
